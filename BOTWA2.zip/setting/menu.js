

global.menu = `*CARA ORDER:*
ketik stun + kodeProduk + target
contoh
order wdp 1234567 6565

untuk melihat kode produk silahkan ketikan list di bawah ini
===============================

╭❒ 「  *SIMPEL LIST*  」
│
│✄┈┈┈⟬ *Games* ⟭ •
│› listml (Mobile Legends)
│› listff (Free Fire)
│› listwdp (Weekly Diamond Pass)
│› listlol (League of Legends Wild Rift)
│› listcoc (Clash of Clans)
│› listpubg (Pubg Mobile)
│› listundawn (Undawn)
│› listgenshin (Genshin Impact)
│
│✄┈┈┈⟬ *Pulsa* ⟭ •
│› xl (XL)
│› tri (TRI)
│› byu (by.U)
│› axis (AXIS)
│› isat (INDOSAT)
│› tsel (TELKOMSEL)
│› smartf (SMARTFREN)
│› token (TOKEN LISTRIK)
│
│✄┈┈┈⟬ *E-Money* ⟭ •
│› ovo
│› grab
│› dana
│› gopay
│› shope
│› maxim
│
╰❒

╭❒ 「  *MENU DEPO*  」
│
│› depo
│› bukti
│› saldo
│› caradepo
│
╰❒

╭❒ 「  *MENU TOPUP*  」
│
│› stun
│› detail
│› cektransaksi
│
╰❒

Mau request Game / Produk? Silahkan ketik :
.req Teksnya

Contoh :
.req Min tambahin Game FF dong`

global.mfun = `
╭✄┈┈┈⟬ *LEADERBOARD* ⟭ •
┆✰ .Toporder
┆✰ .Topdeposit
┆✰ .Topbalance
┆✰ .Toplayanan
╰──────────◇ •

╭✄┈┈┈⟬ *MAIN MENU* ⟭ •
┆◩ .kila ( Ngobrol Sama Kilaa ) 
┆◩ .help ( Lihat Menu )
┆◩ .sewa ( Info Untuk Join Grup )
┆◩ .rules ( Rules Bot )
┆◩ .depo ( Untuk Deposit )
┆◩ .infome ( Untuk Lihat Info Anda )
┆◩ .infouser ( Untuk Lihat Info User ) ×
┆◩ .runtime ( Status Bot Aktif )
┆◩ .leaderboard ( Peringkat Saldo )
╰──────────◇ •

╭✄┈┈┈⟬ *STORE MENU* ⟭ •
┆◪ .menu ( Lihat List Menu )
┆◪ .deposit ( Untuk Isi Ulang Saldo )
┆◪ .buyprem  ( Info Status Premium )
┆◪ .caradepo ( Panduan Isi Ulang Saldo )
┆✄┈┈┈⟬ *CALC* ⟭ •
┆◪ .kali
┆◪ .bagi
┆◪ .tambah
┆◪ .kurang
╰──────────◇ •

╭✄┈┈┈⟬ *FITUR RATE BAHAN* ⟭ •
┆± .soc (Smile of Coin)
┆± .rvalo (Valorant)
┆± .raov (Arena Of Valor)
┆± .socl (Gatau)
┆± .kios (Kios Games)
┆± .kachi (Kachi Shop)
┆± .uniph (Unipin Philipina)
┆± .unibrl (Unipin Brazil)
┆± .rcodm (Call Of Duty Mobile)
┆± .unimy (Unipin Malay)
┆± .rundawn (Garena Undawn)
┆± .unicodm (Unipin Cal Of Duty M)
┆± .aceracer (Gatau)
┆± .genshinph (Genshin Impact)
┆± .genshinmy (Genshin Malay)
╰──────────◇ •

╭✄┈┈┈⟬ *CALC ML* ⟭ •
┆± .cwr (Menghitung Target Winrate)
┆± .cz (Menghitung Diamond Zodiac)
╰──────────◇ •

╭✄┈┈┈⟬ *FITUR STALK* ⟭ •
┆◪ .mlstalk (Cek ML)
┆◪ .stalkff (Cek Free Fire)
┆◪ .stalkpubg (Cek PUBG)
┆◪ .stalkcod (Cek CODM)
┆◪ .stalkhdi (Cek Higgs Domino)
┆◪ .stalksg (Cek Sausageman)
┆◪ .stalkcoc (Cek COC)
┆◪ .stalkig (Cek Instagram)
┆◪ .stalktt (Cek Tiktok)
┆◪ .stalkyt (Cek Youtube)
┆◪ .stalktwitter (Cek Twitter)
┆◪ .stalkgithub (Cek Github)
╰──────────◇ •

╭✄┈┈┈⟬ *FITUR PREMIUM* ⟭ •
┆🅥 .qc
┆🅥 .remini  
┆🅥 .openai
┆🅥 .cekprem 
┆🅥 .listprem
┆🅥 .jadianime
╰──────────◇ •

╭✄┈┈┈⟬ *FITUR GROUP* ⟭ •
┆❐ list
┆❐ bot
┆❐ d
┆❐ p
┆❐ del
┆❐ tagall
┆❐ linkgc
┆❐ add
┆❐ kick
┆❐ open
┆❐ close
┆❐ leave
┆❐ addlist
┆❐ updatelist
┆❐ dellist
┆❐ promote
┆❐ demote
┆❐ revoke
┆❐ antilink
┆❐ antiwame
┆❐ hidetag
┆❐ setnamegc
┆❐ setppgc
┆❐ setwelcome
┆❐ delsetwelcome
┆❐ changewelcome
┆❐ setleft
┆❐ changeleft
┆❐ delsetleft
┆❐ jadian
┆❐ jodohku
┆❐ setbot
┆❐ updatesetbot
┆❐ delsetbot
╰──────────◇ •

╭✄┈┈┈⟬ *DOWNLOADER* ⟭ •
┆❐ .igdl
┆❐ .ttdl
┆❐ .ttvn
┆❐ .ttmp3
┆❐ .ytmp4
┆❐ .ytmp3
┆❐ .aiimage
┆❐ .ytsearch
┆❐ .pinterest
┆❐ .mediafire
╰──────────◇ •

╭✄┈┈┈⟬ *CONVERT* ⟭ •
┆❐ .s
┆❐ .ttp
┆❐ .attp
┆❐ .tourl
┆❐ .toimg
┆❐ .tomp3
┆❐ .toaudio
╰──────────◇ •

╭✄┈┈┈⟬ *OWNER MENU* ⟭ •
┆♛ .join
┆♛ .listban
┆♛ .unban
┆♛ .ban
┆♛ .ping
┆♛ .getip
┆♛ .listuser
┆♛ .getip
┆♛ .restart
┆♛ .updateprofit
┆♛ .profit
┆♛ .delboard
┆♛ .reserboard
┆♛ .delboard
┆♛ .stalk on / off
┆♛ .receipt on / off
┆♛ .ceksaldo
┆♛ .addblnc
┆♛ .lessblnc
┆♛ .addvip
┆♛ .delvip
┆♛ .addvvip
┆♛ .delvvip
┆♛ .listvip
┆♛ .listvvip
┆♛ .addprem
┆♛ .delprem
┆♛ .listprem
┆♛ .leave
┆♛ .block
┆♛ .unblock
┆♛ .sendsesi
┆♛ .broadcast 
┆♛ .addsewa
┆♛ .delsewa
╰──────────◇ •`
global.mmain = `╭✄┈┈┈⟬ *MAIN MENU* ⟭ •
┆◩ .kila ( Ngobrol Sama Kilaa ) 
┆◩ .help ( Lihat Menu )
┆◩ .sewa ( Info Untuk Join Grup )
┆◩ .rules ( Rules Bot )
┆◩ .depo ( Untuk Deposit )
┆◩ .infome ( Untuk Lihat Info Anda )
┆◩ .infouser ( Untuk Lihat Info User ) 
┆◩ .runtime ( Status Bot Aktif )
┆◩ .leaderboard ( Peringkat Saldo )
╰──────────◇ •`
global.mrate = `╭✄┈┈┈⟬ *FITUR RATE BAHAN* ⟭ •
┆± .soc (Smile of Coin)
┆± .rvalo (Valorant)
┆± .raov (Arena Of Valor)
┆± .socl (Gatau)
┆± .kios (Kios Games)
┆± .kachi (Kachi Shop)
┆± .uniph (Unipin Philipina)
┆± .unibrl (Unipin Brazil)
┆± .rcodm (Call Of Duty Mobile)
┆± .unimy (Unipin Malay)
┆± .rundawn (Garena Undawn)
┆± .unicodm (Unipin Cal Of Duty M)
┆± .aceracer (Gatau)
┆± .genshinph (Genshin Impact)
┆± .genshinmy (Genshin Malay)
╰──────────◇ •`
global.mcalc = `╭✄┈┈┈⟬ *CALC ML* ⟭ •
┆± .cwr (Menghitung Target Winrate)
┆± .cz (Menghitung Diamond Zodiac)
╰──────────◇ •`
global.mstalk = `╭✄┈┈┈⟬ *FITUR STALK* ⟭ •
┆◪ .mlstalk (Cek ML)
┆◪ .stalkff (Cek Free Fire)
┆◪ .stalkpubg (Cek PUBG)
┆◪ .stalkcod (Cek CODM)
┆◪ .stalkhdi (Cek Higgs Domino)
┆◪ .stalksg (Cek Sausageman)
┆◪ .stalkcoc (Cek COC)
┆◪ .stalkig (Cek Instagram)
┆◪ .stalktt (Cek Tiktok)
┆◪ .stalkyt (Cek Youtube)
┆◪ .stalktwitter (Cek Twitter)
┆◪ .stalkgithub (Cek Github)
╰──────────◇ •`
global.msimple = `╭✄┈┈┈⟬ *SIMPEL MENU* ⟭ •
┆✓ .SIMPELLIST
┆✓ .LEADERBOARD
┆✓ .MAINMENU
┆✓ .STOREMENU
┆✓ .RATE
┆✓ .CALCML
┆✓ .MENUSTALK
┆✓ .MENUPREMIUM
┆✓ .MENUGROUP
┆✓ .DOWNLOADER
┆✓ .CONVERT
┆✓ .ALLMENU
┆✓ .OWNERMENU
╰──────────◇ •`
global.mstore = `╭✄┈┈┈⟬ *STORE MENU* ⟭ •
┆◪ .menu ( Lihat List Menu )
┆◪ .deposit ( Untuk Isi Ulang Saldo )
┆◪ .buyprem  ( Info Status Premium )
┆◪ .caradepo ( Panduan Isi Ulang Saldo )
┆✄┈┈┈⟬ *CALC* ⟭ •
┆◪ .kali
┆◪ .bagi
┆◪ .tambah
┆◪ .kurang
╰──────────◇ •`
global.leader = `╭✄┈┈┈⟬ *LEADERBOARD* ⟭ •
┆✰ .Toporder
┆✰ .Topdeposit
┆✰ .Topbalance
┆✰ .Toplayanan
╰──────────◇ •`
global.mprem = `╭✄┈┈┈⟬ *FITUR PREMIUM* ⟭ •
┆🅥 .qc
┆🅥 .kenon
┆🅥 .remini  
┆🅥 .openai
┆🅥 .cekprem 
┆🅥 .listprem
┆🅥 .jadianime
╰──────────◇ •`
global.mgroup = `╭✄┈┈┈⟬ *FITUR GROUP* ⟭ •
┆❐ list
┆❐ bot
┆❐ d
┆❐ p
┆❐ del
┆❐ tagall
┆❐ linkgc
┆❐ add
┆❐ kick
┆❐ open
┆❐ close
┆❐ leave
┆❐ addlist
┆❐ updatelist
┆❐ dellist
┆❐ promote
┆❐ demote
┆❐ revoke
┆❐ antilink
┆❐ antiwame
┆❐ hidetag
┆❐ setnamegc
┆❐ setppgc
┆❐ setwelcome
┆❐ delsetwelcome
┆❐ changewelcome
┆❐ setleft
┆❐ changeleft
┆❐ delsetleft
┆❐ jadian
┆❐ jodohku
┆❐ setbot
┆❐ updatesetbot
┆❐ delsetbot
╰──────────◇ •`
global.mdownl = `╭✄┈┈┈⟬ *DOWNLOADER* ⟭ •
┆❐ .igdl
┆❐ .ttdl
┆❐ .ttvn
┆❐ .ttmp3
┆❐ .ytmp4
┆❐ .ytmp3
┆❐ .aiimage
┆❐ .ytsearch
┆❐ .pinterest
┆❐ .mediafire
╰──────────◇ •`
global.convert = `╭✄┈┈┈⟬ *CONVERT* ⟭ •
┆❐ .s
┆❐ .ttp
┆❐ .attp
┆❐ .tourl
┆❐ .toimg
┆❐ .tomp3
┆❐ .toaudio
╰──────────◇ •`
global.mowner= `╭✄┈┈┈⟬ *OWNER MENU* ⟭ •
┆♛ .join
┆♛ .listban
┆♛ .unban
┆♛ .ban
┆♛ .ping
┆♛ .getip
┆♛ .listuser
┆♛ .getip
┆♛ .restart
┆♛ .updateprofit
┆♛ .profit
┆♛ .delboard
┆♛ .reserboard
┆♛ .delboard
┆♛ .stalk on / off
┆♛ .receipt on / off
┆♛ .ceksaldo
┆♛ .addblnc
┆♛ .lessblnc
┆♛ .addvip
┆♛ .delvip
┆♛ .addvvip
┆♛ .delvvip
┆♛ .listvip
┆♛ .listvvip
┆♛ .addprem
┆♛ .delprem
┆♛ .listprem
┆♛ .leave
┆♛ .block
┆♛ .unblock
┆♛ .sendsesi
┆♛ .broadcast 
┆♛ .addsewa
┆♛ .delsewa
╰──────────◇ •`