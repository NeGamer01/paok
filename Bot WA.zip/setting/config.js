
const fs = require("fs");
const chalk = require("chalk");
const moment = require('moment-timezone');

global.ownerr = "6285171502270"; //untuk send receipt data
//━━━━━━━━━━━━━━━[ DATA BOT ]━━━━━━━━━━━━━━━━━//
global.owner = ["6285171502270"];             // Isi Jadi Nomer Owner
global.packname = "Payah Top";    // Isi Jadi Nama Bot
global.author = "Bagas Choi";             // Nama Owner atau biarin saja
global.versionscript = "8.4.0"; 
global.session = "session";
global.logo = 'https://telegra.ph/file/beca313f1262ceddaa20e.png'; //untuk receipt
global.background = 'https://telegra.ph/file/beca313f1262ceddaa20e.png'; // receipt
//━━━━━━━━━━━━━━━[ DATA DIGIFLAZZ ]━━━━━━━━━━━━━━━━━//
global.userme = "wolahoD7l2KW";    // ISI USERNAME DIGI
global.production = "5ade024f-244c-5df8-9b3f-8126302183b2"    // ISI PRODUCTION DIGI; 

global.dimensionLicense = "We1X7xZqB4" // apikeynya di sini https://api.gathstore.id/login/
global.apiUri = "https://api.sosmed-booster.my.id/api/"
// Payment Deposit
global.tujuan = {
	qris: fs.readFileSync(`./db/qris.jpg`),
    bca: 'kosong',
    gopay: '085171502270',
    dana: '085171502270',
    shopeepay: '085171502270',
 }
 global.atasnama = {
	qris: '-',
    bca: 'kosong',
    gopay: 'Bagas C***l A**n',
    dana: 'Bagas C***l A**n',
    shopeepay: 'Bagas C***l A**n',
 }
global.minimal = {
    qris: 100,
    bca: 100,
    gopay: 100,
    dana: 100,
    shopeepay: 100,
}

// Website Api
global.APIs = {
  zenz: "https://api.zahwazein.xyz",
  lol: "https://api.lolhuman.xyz",
};

// Apikey Website Api
global.APIKeys = {
  "https://api.zahwazein.xyz": "zenzkey_6c68a82640", 
  "https://api.lolhuman.xyz": "f0b105c1634b810b34523af0",
};
// Zenzkey & Lolkey
global.zenzkey = "zenzkey_6c68a82640";
global.lolkey = "virtualDimension";
global.domain = "-";
global.ptla = "kosong"

//PAYDISINI.CO.ID
global.paydisini = 'e01c727ad7ec477b00134609e5606954'; // Gantilah dengan API Key Anda
global.noted = 'Catatan transaksi dari merchant'; // Gantilah dengan catatan dari merchant
global.timeStamp = 1800; // Gantilah dengan batas waktu pembayaran (detik)
global.tipeFee = 1; // Gantilah dengan jenis fee (1: ditanggung customer, 2: ditanggung merchant)


global.limite = {
	limitCount: 'Unlimited',
    prem: 'Unlimited',
    user:  'Unlimited',
	}
global.mess = {
  error: "Error",
  wait: "Mohon Tunggu Sebentar, Permintaan Anda Sedang di Proses.....",
  owner: "Fitur Khusus Owner Bot",
  waitdata: "Melihat Data Terkini...",
  admin: "Fitur Khusus Admin Group!",
  group: "Fitur Digunakan Hanya Untuk Group!",
  private: 'Fitur Digunakan Hanya Untuk Private Chat!',
  botAdmin: "Bot Harus Menjadi Admin Terlebih Dahulu!",
  kon: `Digiflazz apikey kamu masih kosong nih, Tolong diisi konfigurasi nya dulu yah`
};

global.tanggalserver = `${moment().tz("Asia/Jakarta").format("ll")}`;
global.waktuserver = `${moment.tz('Asia/Jakarta').format('HH:mm:ss')}`; 

let http = require('http')
            http.get({'host': 'api.ipify.org', 'port': 80, 'path': '/'}, function(resp) {
            resp.on('data', function(ip) {
                (global.ipserver = ip);
            })
          })

          let file = require.resolve(__filename);
          fs.watchFile(file, () => {
            fs.unwatchFile(file);
            console.log(chalk.redBright(`Update ${__filename}`));
            delete require.cache[file];
            require(file);
          });
          