const fs = require('fs')
const chalk = require('chalk')
const stalkerController = require('../controller/stalkerController')
function stalkUsername(command, reply, m, text, level){
    switch(command){
        case 'stalkml': {
          const ea = text.split(' ')
          if (!text) return reply('user id nya mana?')
            stalkerController('game', 'mobile-legends', ea[0], ea[1])
          .then(data => {
            const username = data.nickname
            const userid = data.userid
           let result = '' 

           if (username === null || userid === null){
            result = `userId username tidak di temukan`
          } else {
            result = `_*Mobile Legends Check*_
            
*Username:* ${username}
*UserId:* ${userid}`
}

reply(result)
            console.log(data);
          }) 
          .catch(error => {
            reply('User Gagal Di temukan')
            console.error(error);
          });
        }
        break
        case 'stalkhdi': {
          const ea = text.split(' ')
          if (!text) return reply('user id nya mana?')
            stalkerController('game', 'higgs-domino', ea[0], ea[1])
          .then(data => {
            const username = data.nickname
            const userid = data.userid
           let result = '' 

           if (username === null || userid === null){
            result = `userId username tidak di temukan`
          } else {
            result = `*Higgs Domino Check*
            
*Username:* ${username}
*UserId:* ${userid}`
}

reply(result)
            console.log(data);
          }) 
          .catch(error => {
            reply('User Gagal Di temukan')
            console.error(error);
          });
        }
        break
        case 'stalkff': {
          const ea = text.split(' ')
          if (!text) return reply('user id nya mana?')
            stalkerController('game', 'free-fire', ea[0], ea[1])
          .then(data => {
            const username = data.nickname
            const userid = data.userid
           let result = '' 

           if (username === null || userid === null){
            result = `userId username tidak di temukan`
          } else {
            result = `_*Free Fire Check*_
            
*Username:* ${username}
*UserId:* ${userid}`
}

reply(result)
            console.log(data);
          }) 
          .catch(error => {
            reply('User Gagal Di temukan')
            console.error(error);
          });
        }
        break
        case 'stalkaov': {
          const ea = text.split(' ')
          if (!text) return reply('user id nya mana?')
            stalkerController('game', 'aov', ea[0], ea[1])
          .then(data => {
            const username = data.nickname
            const userid = data.userid
           let result = '' 

           if (username === null || userid === null){
            result = `userId username tidak di temukan`
          } else {
            result = `_*AOV Check*_
            
*Username:* ${username}
*UserId:* ${userid}`
}

reply(result)
            console.log(data);
          }) 
          .catch(error => {
            reply('User Gagal Di temukan')
            console.error(error);
          });
        }
        break
        case 'stalkau2m': {
          const ea = text.split(' ')
          if (!text) return reply('user id nya mana?')
            stalkerController('game', 'au2m', ea[0], ea[1])
          .then(data => {
            const username = data.nickname
            const userid = data.userid
           let result = '' 

           if (username === null || userid === null){
            result = `userId username tidak di temukan`
          } else {
            result = `_*AU2 Mobile Check*_
            
*Username:* ${username}
*UserId:* ${userid}`
}

reply(result)
            console.log(data);
          }) 
          .catch(error => {
            reply('User Gagal Di temukan')
            console.error(error);
          });
        }
        break
case 'stalkml2': {
  const mooCountry = require("../lib/region");
  const ea = text.split(' ')
  if (!text) return reply('user id nya mana?')
    stalkerController('game', 'mlreg', ea[0], ea[1])
  .then(data => {
    const decodedNickname = decodeURIComponent(data.nickname)
    const count = mooCountry(data.userid)
   let result = '' 

   if (decodedNickname === null || count === null){
    result = `userId username tidak di temukan`
  } else {
    result =`*Mobile Legends*
Nickname: ${decodedNickname}
User ID: ${ea[0]}(${ea[1]})
*Negara:* ${count}`;
}

reply(result)
    console.log(data);
  }) 
  .catch(error => {
    reply('User Gagal Di temukan')
    console.error(error);
  });
}
break
    }
}
module.exports = stalkUsername
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright(`Update ${__filename}`));
  delete require.cache[file];
  require(file);
});

